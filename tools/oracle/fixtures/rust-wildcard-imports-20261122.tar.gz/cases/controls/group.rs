pub mod a { pub mod b { pub fn one(){} pub fn two(){} } pub mod c { pub fn three(){} pub fn four(){} } }
pub mod d {
    use crate::a::{
        b::*,
        c::*,
    };
    pub fn run(){one();two();three();four();}
}
pub mod e {
    use crate::a::b :: *;
    pub fn run(){one();two();}
}
pub mod f {
    use crate::a::c::{*};
    pub fn run(){three();four();}
}
